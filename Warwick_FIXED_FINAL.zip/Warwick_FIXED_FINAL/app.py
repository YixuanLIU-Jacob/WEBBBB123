from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/course-all')
def course_all():
    return render_template('course-all.html')

@app.route('/contact-us')
def contact_us():
    return render_template('contact-us.html')

@app.route('/apply-for-course')
def apply_for_course():
    return render_template('apply-for-course.html')

@app.route('/course-business')
def course_business():
    return render_template('course-business.html')

@app.route('/course-science')
def course_science():
    return render_template('course-science.html')

@app.route('/course-tech')
def course_tech():
    return render_template('course-tech.html')

@app.route('/frame-13')
def frame_13():
    return render_template('frame-13.html')

@app.route('/frame-18')
def frame_18():
    return render_template('frame-18.html')

@app.route('/order-place-successfully')
def order_place_successfully():
    return render_template('order-place-successfully.html')

@app.route('/pyton-overview-1')
def pyton_overview_1():
    return render_template('pyton-overview-1.html')

@app.route('/pyton-overview-2')
def pyton_overview_2():
    return render_template('pyton-overview-2.html')

@app.route('/register')
def register():
    return render_template('register.html')


app.run(port=5001)
